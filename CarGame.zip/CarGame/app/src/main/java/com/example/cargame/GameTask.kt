package com.example.cargame

interface GameTask {
    fun closeGame(mScore: Int)
}